#!/usr/bin/env node

/**
 * GitNarrative CLI 入口
 *
 * 让 Git 仓库讲出自己的故事
 * 基于晶脉哲学 SNI 架构与谐振动力学
 */

import { Command } from 'commander';
import chalk from 'chalk';
import { GitParser } from '../core/git-parser';
import { HarmonyEngine } from '../core/harmony-engine';
import { NarrativeGenerator } from '../core/narrative-generator';
import { EvolutionPhase } from '../core/types';

const program = new Command();

console.log('');
console.log(chalk.cyan('  GitNarrative —— 让 Git 仓库拥有自我叙事能力'));
console.log(chalk.gray('  基于晶脉哲学 SNI 架构 · H = U - D - A'));
console.log('');

program
  .name('git-narrative')
  .description('生成 Git 仓库的演化自传')
  .version('1.0.0')
  .argument('[path]', '仓库路径', '.')
  .option('-n, --max-commits <number>', '最大分析commit数', '500')
  .option('-s, --since <date>', '起始日期（如 2024-01-01）', '')
  .option('-u, --until <date>', '结束日期', '')
  .option('-b, --branch <name>', '指定分支', '')
  .option('--json', '以JSON格式输出完整报告')
  .option('--chapters-only', '仅显示章节列表')
  .action(async (repoPath: string, options: any) => {
    try {
      const parser = new GitParser(repoPath);
      const engine = new HarmonyEngine();
      const generator = new NarrativeGenerator();

      console.log(chalk.gray('  正在解析 Git 历史...'));
      const commits = parser.parse({
        repoPath,
        maxCommits: parseInt(options.maxCommits) || 500,
        since: options.since || undefined,
        until: options.until || undefined,
        branch: options.branch || undefined
      });

      if (commits.length === 0) {
        console.log(chalk.yellow('  未找到提交记录。'));
        console.log(chalk.gray('  请确认该路径是一个有效的 Git 仓库。'));
        return;
      }

      console.log(chalk.gray(`  已解析 ${commits.length} 次提交，正在计算和谐度曲线 H(t)...`));
      const snapshots = engine.computeHarmonyCurve(commits);

      console.log(chalk.gray('  正在生成项目演化自传...'));
      const projectName = repoPath === '.'
        ? (process.cwd().split(/[\\/]/).pop() || 'unknown')
        : repoPath.split(/[\\/]/).pop() || 'unknown';
      const autobiography = generator.generate(projectName, commits, snapshots);

      if (options.json) {
        console.log(JSON.stringify(autobiography, null, 2));
        return;
      }

      printAutobiography(autobiography, options.chaptersOnly || false);
    } catch (error) {
      console.error(chalk.red('  分析失败:'), error instanceof Error ? error.message : error);
      process.exit(1);
    }
  });

/**
 * 打印项目自传
 */
function printAutobiography(autobiography: any, chaptersOnly: boolean): void {
  const {
    projectName,
    totalCommits,
    totalContributors,
    timespan,
    chapters,
    overallHarmony,
    evolutionStory
  } = autobiography;

  // 头部信息
  console.log('');
  console.log(chalk.bold.cyan('═'.repeat(60)));
  console.log(chalk.bold.cyan(`  ${projectName} —— 项目演化自传`));
  console.log(chalk.bold.cyan('═'.repeat(60)));
  console.log('');
  console.log(`  提交总数: ${chalk.bold(String(totalCommits))}`);
  console.log(`  贡献者数: ${chalk.bold(String(totalContributors))}`);
  console.log(`  时间跨度: ${timespan.start.toISOString().split('T')[0]} ~ ${timespan.end.toISOString().split('T')[0]}`);
  console.log(`  整体和谐度: ${colorHarmony(overallHarmony)}`);
  console.log('');

  if (chaptersOnly) {
    chapters.forEach((chapter: any, index: number) => {
      const emoji = getPhaseEmoji(chapter.phase);
      console.log(`  ${index + 1}. ${emoji} ${chapter.title}  [${chapter.harmonyCurve}]`);
    });
    return;
  }

  // 演化叙事
  console.log(chalk.bold.cyan('─'.repeat(60)));
  console.log(chalk.bold('  演化叙事'));
  console.log(chalk.bold.cyan('─'.repeat(60)));
  console.log('');
  console.log(evolutionStory);
  console.log('');

  // 章节详情
  console.log(chalk.bold.cyan('─'.repeat(60)));
  console.log(chalk.bold('  章节详情'));
  console.log(chalk.bold.cyan('─'.repeat(60)));

  chapters.forEach((chapter: any, index: number) => {
    const emoji = getPhaseEmoji(chapter.phase);
    console.log('');
    console.log(chalk.bold(`  第${index + 1}章：${emoji} ${chapter.title}`));
    console.log(chalk.gray(`  ${chapter.summary}`));
    console.log(`  和谐度: ${chapter.harmonyCurve}`);
    if (chapter.keyEvents && chapter.keyEvents.length > 0) {
      console.log(`  关键事件: ${chapter.keyEvents.join('；')}`);
    }
    if (chapter.contributors && chapter.contributors.length > 0) {
      console.log(`  主要贡献者: ${chapter.contributors.join(', ')}`);
    }
  });

  console.log('');
  console.log(chalk.bold.cyan('═'.repeat(60)));
  console.log(chalk.gray('  分析完成 · 基于晶脉哲学谐振动力学 · Apache 2.0'));
  console.log(chalk.bold.cyan('═'.repeat(60)));
}

/**
 * 和谐度着色
 */
function colorHarmony(harmony: number): string {
  if (harmony >= 0.8) return chalk.green.bold((harmony * 100).toFixed(1) + '%');
  if (harmony >= 0.6) return chalk.green((harmony * 100).toFixed(1) + '%');
  if (harmony >= 0.4) return chalk.yellow((harmony * 100).toFixed(1) + '%');
  return chalk.red((harmony * 100).toFixed(1) + '%');
}

/**
 * 获取阶段emoji
 */
function getPhaseEmoji(phase: EvolutionPhase): string {
  const emojis: Record<string, string> = {
    'steady': '📐',
    'restructuring': '🔧',
    'chaotic': '🌪️',
    'stagnant': '💤',
    'harmonic': '✨'
  };
  return emojis[phase] || '📌';
}

program.parse(process.argv);