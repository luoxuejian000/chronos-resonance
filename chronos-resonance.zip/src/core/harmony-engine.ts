/** 
 * 谐振核心引擎 
 * 
 * 计算 Git 仓库的和谐度曲线 H(t)。 
 * 这是晶脉哲学谐振调谐论在软件工程领域的核心实现。 
 * 
 * 和谐度函数：H = λᵤ·U - λᴅ·D - λₐ·A 
 * 
 * U (统一性 Unity)：commit 修改的聚焦度、文件耦合的紧密程度。 
 *   关系本体论指出：存在即被关系网络定位。U 度量的是 commit 在文件关系 
 *   网络中的"定位清晰度"——修改越聚焦，该 commit 在关系网络中的位置越明确。 
 * 
 * D (发展性 Development)：新功能引入频率、代码增长速率。 
 *   一个健康的项目应该持续引入新功能，但不过度膨胀。 
 * 
 * A (对抗性 Antagonism)：修复频率、回滚频率、冲突频率。 
 *   矛盾动力论指出：矛盾不是故障，而是系统演化的能量源。 
 *   高A不一定是坏事（剧烈重构期），但持续高A意味着结构性问题。 
 */ 
 
import { CommitInfo, HarmonySnapshot, EvolutionPhase } from './types'; 
import { CONFIG } from './config'; 
 
export class HarmonyEngine { 
  private readonly weights = CONFIG.weights; 
  private readonly thresholds = CONFIG.thresholds; 
 
  /** 
   * 计算和谐度曲线 
   * 
   * 使用滑动窗口方法，在每个窗口上计算 U/D/A/H 四元组， 
   * 然后通过移动平均平滑曲线。 
   * 
   * @param commits 按时间排序的commit数组 
   * @returns 和谐度快照序列，即 H(t) 曲线的采样点 
   */ 
  public computeHarmonyCurve(commits: CommitInfo[]): HarmonySnapshot[] { 
    if (commits.length === 0) { 
      return []; 
    } 
 
    // 确保按时间排序 
    const sortedCommits = [...commits].sort( 
      (a, b) => a.date.getTime() - b.date.getTime() 
    ); 
 
    const snapshots: HarmonySnapshot[] = []; 
    const windowSize = CONFIG.narrative.chapterSize; 
    const stepSize = Math.max(1, Math.floor(windowSize / 2)); 
 
    // 滑动窗口遍历 
    for (let centerIndex = 0; centerIndex < sortedCommits.length; centerIndex += stepSize) { 
      const windowStart = Math.max(0, centerIndex - Math.floor(windowSize / 2)); 
      const windowEnd = Math.min(sortedCommits.length, centerIndex + Math.floor(windowSize / 2)); 
      const window = sortedCommits.slice(windowStart, windowEnd); 
 
      if (window.length < 2) { 
        continue; // 窗口太小，跳过 
      } 
 
      const U = this.computeUnity(window); 
      const D = this.computeDevelopment(window); 
      const A = this.computeAntagonism(window); 
 
      // H = λᵤ·U - λᴅ·D - λₐ·A + 基础分 
      // 基础分(0.3)防止过度惩罚，保持评分在合理区间 
      const rawH = this.weights.consistency * U - 
                   this.weights.development * D - 
                   this.weights.antagonism * A + 
                   0.3; 
 
      const H = Math.max(0, Math.min(1, rawH)); 
      const phase = this.classifyPhase(U, D, A, H); 
 
      snapshots.push({ 
        timestamp: window[window.length - 1].date, 
        U: Math.round(U * 100) / 100, 
        D: Math.round(D * 100) / 100, 
        A: Math.round(A * 100) / 100, 
        H: Math.round(H * 100) / 100, 
        commitCount: window.length, 
        phase 
      }); 
    } 
 
    return this.smoothSnapshots(snapshots); 
  } 
 
  /** 
   * 计算统一性 U 
   * 
   * 度量两个维度： 
   * 1. 文件聚焦度：每次commit修改的文件数是否适中（3-8个文件最理想） 
   * 2. 消息主题一致性：commit消息是否围绕统一主题 
   */ 
  private computeUnity(window: CommitInfo[]): number { 
    if (window.length <= 1) { 
      return 0.8; // 单次提交默认为聚焦的 
    } 
 
    // 文件聚焦度：平均修改文件数越接近5（理想值），得分越高 
    const totalFilesChanged = window.reduce((sum, commit) => sum + commit.filesChanged, 0); 
    const averageFilesChanged = totalFilesChanged / window.length; 
 
    const idealFilesChanged = 5; // 理想值：每次修改约5个文件 
    const maxDeviation = 15;     // 最大允许偏差 
    const fileFocusScore = averageFilesChanged > 0 
      ? Math.max(0, 1 - Math.abs(averageFilesChanged - idealFilesChanged) / maxDeviation) 
      : 0.5; 
 
    // 消息主题一致性：唯一关键词密度越低，主题越聚焦 
    const messages = window.map(commit => commit.message.toLowerCase()); 
    const uniqueKeywords = new Set<string>(); 
 
    for (const message of messages) { 
      const words = message.split(/\s+/).filter(word => word.length > 3); 
      for (const word of words) { 
        uniqueKeywords.add(word); 
      } 
    } 
 
    const keywordDensity = uniqueKeywords.size / (messages.length * 3 + 1); 
    const messageFocusScore = Math.max(0, 1 - keywordDensity); 
 
    // 文件聚焦度权重更高，因为它是更客观的指标 
    return fileFocusScore * 0.6 + messageFocusScore * 0.4; 
  } 
 
  /** 
   * 计算发展性 D 
   * 
   * 度量三个维度： 
   * 1. 插入/删除比：高比值表示新功能开发 
   * 2. 新文件创建率：insertion远大于deletion的commit占比 
   * 3. 提交频率：每天的平均commit数 
   */ 
  private computeDevelopment(window: CommitInfo[]): number { 
    if (window.length <= 1) { 
      return 0.3; // 单次提交无法判断发展性 
    } 
 
    // 插入/删除比 
    const totalInsertions = window.reduce((sum, commit) => sum + commit.insertions, 0); 
    const totalDeletions = window.reduce((sum, commit) => sum + commit.deletions, 0); 
    const insertDeleteRatio = totalDeletions > 0 
      ? totalInsertions / (totalInsertions + totalDeletions) 
      : 0.8; 
 
    // 新文件创建率：insertion > deletion * 3 且 insertion > 50 的commit 
    const creationCommits = window.filter( 
      commit => commit.insertions > commit.deletions * 3 && commit.insertions > 50 
    ).length; 
    const creationRate = creationCommits / window.length; 
 
    // 提交频率 
    const timeSpan = window[window.length - 1].date.getTime() - window[0].date.getTime(); 
    const daysSpan = Math.max(1, timeSpan / (1000 * 60 * 60 * 24)); 
    const commitFrequency = window.length / daysSpan; 
    const frequencyScore = Math.min(1, commitFrequency / 3); // 每天3次提交为满分 
 
    return insertDeleteRatio * 0.3 + creationRate * 0.4 + frequencyScore * 0.3; 
  } 
 
  /** 
   * 计算对抗性 A 
   * 
   * 度量三个维度的冲突信号： 
   * 1. 修复率：包含 fix/bug/hotfix/revert 等关键词的commit占比 
   * 2. 合并频率：merge commit的占比 
   * 3. 大规模删除频率：单次删除超过阈值的commit占比 
   */ 
  private computeAntagonism(window: CommitInfo[]): number { 
    if (window.length <= 1) { 
      return 0.1; // 单次提交默认低对抗 
    } 
 
    // 修复类commit检测 
    const fixPattern = /\b(fix|bug|hotfix|revert|rollback|patch)\b/i; 
    const fixCommits = window.filter(commit => fixPattern.test(commit.message)).length; 
    const fixRate = fixCommits / window.length; 
 
    // Merge commit频率 
    const mergeCommits = window.filter(commit => commit.isMerge).length; 
    const mergeRate = mergeCommits / window.length; 
 
    // 大规模删除频率 
    const heavyDeletionThreshold = CONFIG.coupling.highDeletionThreshold; 
    const heavyDeletionCommits = window.filter( 
      commit => commit.deletions > heavyDeletionThreshold 
    ).length; 
    const heavyDeletionRate = heavyDeletionCommits / window.length; 
 
    // 综合对抗性得分 
    // 修复率和大规模删除权重较高，因为它们直接影响代码稳定性 
    return fixRate * 0.4 + mergeRate * 0.2 + heavyDeletionRate * 0.4; 
  } 
 
  /** 
   * 根据 U/D/A/H 四元组判断当前演化阶段 
   * 
   * 使用简化的启发式规则，基于和谐度阈值和四元组特征： 
   * - H >= 0.8: 谐振态（Harmonic） 
   * - H >= 0.6: 平稳态（Steady） 
   * - D > 0.6 且 A > 0.4: 剧烈重构期（Restructuring） 
   * - A > 0.5 且 U < 0.3: 混乱调整期（Chaotic） 
   * - D < 0.2 且 H < 0.4: 沉寂停滞期（Stagnant） 
   */ 
  private classifyPhase(U: number, D: number, A: number, H: number): EvolutionPhase { 
    // 谐振态：高和谐度，增长健康 
    if (H >= this.thresholds.harmonic && D > 0.4) { 
      return EvolutionPhase.HARMONIC; 
    } 
 
    // 剧烈重构期：大规模代码替换 
    if (D > 0.6 && A > 0.4) { 
      return EvolutionPhase.RESTRUCTURING; 
    } 
 
    // 混乱调整期：大量修复和回滚 
    if (A > 0.5 && U < 0.3) { 
      return EvolutionPhase.CHAOTIC; 
    } 
 
    // 沉寂停滞期：变更量极低 
    if (D < 0.2 && H < this.thresholds.warning) { 
      return EvolutionPhase.STAGNANT; 
    } 
 
    // 平稳发展期：高U低A，修改聚焦，结构稳定 
    if (H >= this.thresholds.steady) { 
      return EvolutionPhase.STEADY; 
    } 
 
    // 默认：平稳态 
    return EvolutionPhase.STEADY; 
  } 
 
  /** 
   * 平滑和谐度曲线 
   * 
   * 使用移动平均算法减少噪声，使曲线更易读。 
   * 这是谐振调谐论中"去噪聚焦"思想的体现。 
   */ 
  private smoothSnapshots(snapshots: HarmonySnapshot[]): HarmonySnapshot[] { 
    if (snapshots.length <= CONFIG.narrative.smoothingWindow) { 
      return snapshots; 
    } 
 
    const smoothed: HarmonySnapshot[] = []; 
    const window = CONFIG.narrative.smoothingWindow; 
 
    for (let i = 0; i < snapshots.length; i++) { 
      const start = Math.max(0, i - Math.floor(window / 2)); 
      const end = Math.min(snapshots.length, i + Math.ceil(window / 2)); 
      const windowSnapshots = snapshots.slice(start, end); 
 
      const avgU = windowSnapshots.reduce((sum, s) => sum + s.U, 0) / windowSnapshots.length; 
      const avgD = windowSnapshots.reduce((sum, s) => sum + s.D, 0) / windowSnapshots.length; 
      const avgA = windowSnapshots.reduce((sum, s) => sum + s.A, 0) / windowSnapshots.length; 
      const avgH = windowSnapshots.reduce((sum, s) => sum + s.H, 0) / windowSnapshots.length; 
 
      smoothed.push({ 
        timestamp: snapshots[i].timestamp, 
        U: Math.round(avgU * 100) / 100, 
        D: Math.round(avgD * 100) / 100, 
        A: Math.round(avgA * 100) / 100, 
        H: Math.round(avgH * 100) / 100, 
        commitCount: snapshots[i].commitCount, 
        phase: snapshots[i].phase 
      }); 
    } 
 
    return smoothed; 
  } 
 
  /** 
   * 获取演化阶段描述 
   * 
   * 将机器可读的 EvolutionPhase 转换为人类可读的中文描述。 
   */ 
  public getPhaseDescription(phase: EvolutionPhase): string { 
    const descriptions: Record<EvolutionPhase, string> = { 
      [EvolutionPhase.STEADY]: '平稳发展期 — 代码稳步推进，结构健康稳定', 
      [EvolutionPhase.RESTRUCTURING]: '剧烈重构期 — 架构调整，大规模代码替换', 
      [EvolutionPhase.CHAOTIC]: '混乱调整期 — 频繁修复，问题较多需要关注', 
      [EvolutionPhase.STAGNANT]: '沉寂停滞期 — 变更稀少，项目可能处于维护状态', 
      [EvolutionPhase.HARMONIC]: '谐振态 — 增长健康，协作高效，理想的发展状态' 
    }; 
    return descriptions[phase] || '未知状态'; 
  } 
}
