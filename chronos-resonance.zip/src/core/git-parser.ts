/** 
 * Git 历史解析器 
 * 
 * 将 git log 的原始文本输出转化为结构化的 CommitInfo 对象数组。 
 * 这是关系本体论在数据层的实现：每一个 commit 不再是孤立的文本行， 
 * 而是关系网络中的一个可查询、可关联的结构化节点。 
 */ 
 
import { execSync } from 'child_process'; 
import { CommitInfo, ParseOptions } from './types'; 
 
export class GitParser { 
  private readonly repoPath: string; 
 
  /** 
   * @param repoPath Git 仓库的本地路径，默认为当前目录 
   */ 
  constructor(repoPath: string = '.') { 
    this.repoPath = repoPath; 
  } 
 
  /** 
   * 解析 Git 提交历史 
   * 
   * @param options 解析选项 
   * @returns 结构化的 CommitInfo 数组，按时间倒序排列 
   */ 
  public parse(options: ParseOptions = { repoPath: this.repoPath }): CommitInfo[] { 
    const command = this.buildGitLogCommand(options); 
 
    try { 
      const rawOutput = execSync(command, { 
        encoding: 'utf-8', 
        maxBuffer: 50 * 1024 * 1024 // 50MB 缓冲区，支持大型仓库 
      }); 
      return this.parseRawOutput(rawOutput); 
    } catch (error) { 
      const message = error instanceof Error ? error.message : String(error); 
      throw new Error(`Git 历史解析失败: ${message}\n请确认路径 "${this.repoPath}" 是一个有效的 Git 仓库。`); 
    } 
  } 
 
  /** 
   * 构建 git log 命令 
   */ 
  private buildGitLogCommand(options: ParseOptions): string { 
    const { maxCommits, since, until, branch } = options; 
 
    // 使用自定义格式输出：commit信息在一行，统计信息在下一行 
    let command = `git -C "${this.repoPath}" log --pretty=format:"%H|%h|%an|%ae|%ai|%s" --shortstat`; 
 
    if (maxCommits !== undefined) { 
      command += ` -n ${maxCommits}`; 
    } 
    if (since) { 
      command += ` --since="${since}"`; 
    } 
    if (until) { 
      command += ` --until="${until}"`; 
    } 
    if (branch) { 
      command += ` ${branch}`; 
    } 
 
    return command; 
  } 
 
  /** 
   * 解析 git log 原始输出 
   * 
   * 输出格式示例： 
   * abc123...|abc123|John|john@email.com|2024-01-15 10:30:00 +0800|Fix login bug 
   *  2 files changed, 15 insertions(+), 3 deletions(-) 
   */ 
  private parseRawOutput(output: string): CommitInfo[] { 
    const commits: CommitInfo[] = []; 
    const lines = output.split('\n').filter(line => line.trim().length > 0); 
 
    let currentCommit: Partial<CommitInfo> | null = null; 
 
    for (const line of lines) { 
      if (this.isCommitHeaderLine(line)) { 
        // 遇到新的commit头，先保存上一个 
        if (currentCommit !== null && currentCommit.hash) { 
          commits.push(this.finalizeCommit(currentCommit)); 
        } 
        currentCommit = this.parseCommitHeader(line); 
      } else if (currentCommit !== null && this.isStatLine(line)) { 
        // 解析统计行 
        const stats = this.parseStatLine(line); 
        currentCommit.filesChanged = stats.filesChanged; 
        currentCommit.insertions = stats.insertions; 
        currentCommit.deletions = stats.deletions; 
      } 
    } 
 
    // 处理最后一个commit 
    if (currentCommit !== null && currentCommit.hash) { 
      commits.push(this.finalizeCommit(currentCommit)); 
    } 
 
    return commits; 
  } 
 
  /** 
   * 判断是否为commit头行 
   * 格式：hash|shortHash|author|email|date|message 
   */ 
  private isCommitHeaderLine(line: string): boolean { 
    // 统计行也包含数字和文本，但不包含管道符 
    return line.includes('|') && 
           !line.includes('files changed') && 
           !line.includes('insertion') && 
           !line.includes('deletion'); 
  } 
 
  /** 
   * 判断是否为统计行 
   * 格式： N files changed, M insertions(+), K deletions(-) 
   */ 
  private isStatLine(line: string): boolean { 
    return line.includes('files changed') || 
           line.includes('file changed'); 
  } 
 
  /** 
   * 解析commit头行 
   */ 
  private parseCommitHeader(line: string): Partial<CommitInfo> { 
    const parts = line.split('|'); 
 
    if (parts.length < 6) { 
      throw new Error(`无法解析commit行: ${line.substring(0, 100)}`); 
    } 
 
    const message = parts.slice(5).join('|').trim(); 
 
    return { 
      hash: parts[0].trim(), 
      shortHash: parts[1].trim(), 
      author: parts[2].trim(), 
      email: parts[3].trim(), 
      date: new Date(parts[4].trim()), 
      message, 
      filesChanged: 0, 
      insertions: 0, 
      deletions: 0, 
      isMerge: this.isMergeCommit(message), 
      tags: [] 
    }; 
  } 
 
  /** 
   * 解析统计行 
   */ 
  private parseStatLine(line: string): { filesChanged: number; insertions: number; deletions: number } { 
    let filesChanged = 0; 
    let insertions = 0; 
    let deletions = 0; 
 
    const fileMatch = line.match(/(\d+)\s+files?\s+changed/); 
    if (fileMatch !== null) { 
      filesChanged = parseInt(fileMatch[1], 10); 
    } 
 
    const insertionMatch = line.match(/(\d+)\s+insertions?\(\+\)/); 
    if (insertionMatch !== null) { 
      insertions = parseInt(insertionMatch[1], 10); 
    } 
 
    const deletionMatch = line.match(/(\d+)\s+deletions?\(-\)/); 
    if (deletionMatch !== null) { 
      deletions = parseInt(deletionMatch[1], 10); 
    } 
 
    return { filesChanged, insertions, deletions }; 
  } 
 
  /** 
   * 判断是否为合并commit 
   */ 
  private isMergeCommit(message: string): boolean { 
    const lowerMessage = message.toLowerCase(); 
    return lowerMessage.includes('merge') || 
           lowerMessage.includes('合并') || 
           message.startsWith('Merge branch'); 
  } 
 
  /** 
   * 补齐commit信息，确保所有必填字段都有值 
   */ 
  private finalizeCommit(partial: Partial<CommitInfo>): CommitInfo { 
    return { 
      hash: partial.hash || '', 
      shortHash: partial.shortHash || '', 
      author: partial.author || 'unknown', 
      email: partial.email || '', 
      date: partial.date || new Date(), 
      message: partial.message || '', 
      filesChanged: partial.filesChanged || 0, 
      insertions: partial.insertions || 0, 
      deletions: partial.deletions || 0, 
      isMerge: partial.isMerge || false, 
      tags: partial.tags || [] 
    }; 
  } 
}
