/** 
 * 叙事生成器 
 * 
 * 基于和谐度曲线 H(t) 生成项目的"演化自传"。 
 * 这是 SNI（自我叙事整合器）在 Git 历史领域的直接应用。 
 * 
 * SNI 的核心功能： 
 * - 将分散的事件整合为连贯的叙事 
 * - 识别演化阶段的转折点 
 * - 生成人类可读的演化故事 
 */ 
 
import { 
  CommitInfo, 
  HarmonySnapshot, 
  EvolutionPhase, 
  NarrativeChapter, 
  ProjectAutobiography 
} from './types'; 
import { CONFIG } from './config'; 
 
export class NarrativeGenerator { 
 
  /** 
   * 生成项目自传 
   */ 
  public generate( 
    projectName: string, 
    commits: CommitInfo[], 
    snapshots: HarmonySnapshot[] 
  ): ProjectAutobiography { 
    if (commits.length === 0) { 
      return this.emptyAutobiography(projectName); 
    } 
 
    const sortedCommits = [...commits].sort( 
      (a, b) => a.date.getTime() - b.date.getTime() 
    ); 
 
    const chapters = this.divideIntoChapters(snapshots, sortedCommits); 
    const overallHarmony = this.computeOverallHarmony(snapshots); 
    const contributors = this.extractAllContributors(commits); 
    const evolutionStory = this.generateEvolutionStory(chapters, overallHarmony); 
 
    return { 
      projectName, 
      totalCommits: commits.length, 
      totalContributors: contributors.length, 
      timespan: { 
        start: sortedCommits[0].date, 
        end: sortedCommits[sortedCommits.length - 1].date 
      }, 
      chapters, 
      overallHarmony: Math.round(overallHarmony * 100) / 100, 
      evolutionStory 
    }; 
  } 
 
  /** 
   * 创建空的自传（当没有commit时） 
   */ 
  private emptyAutobiography(projectName: string): ProjectAutobiography { 
    const now = new Date(); 
    return { 
      projectName, 
      totalCommits: 0, 
      totalContributors: 0, 
      timespan: { start: now, end: now }, 
      chapters: [], 
      overallHarmony: 0, 
      evolutionStory: '这个项目还没有任何提交记录，等待着第一个开发者来书写它的故事。' 
    }; 
  } 
 
  /** 
   * 将和谐度快照和commit划分成章节 
   * 
   * 章节划分策略： 
   * 1. 按演化阶段的转折点分割 
   * 2. 每个章节包含约 N 个 commit（N = chapterSize） 
   * 3. 章节之间至少间隔最小天数 
   */ 
  private divideIntoChapters( 
    snapshots: HarmonySnapshot[], 
    commits: CommitInfo[] 
  ): NarrativeChapter[] { 
    if (snapshots.length === 0) { 
      return []; 
    } 
 
    const chapters: NarrativeChapter[] = []; 
    const chapterSize = CONFIG.narrative.chapterSize; 
    const minDuration = CONFIG.narrative.minChapterDuration; 
 
    let currentPhase = snapshots[0].phase; 
    let chapterStartIndex = 0; 
 
    for (let i = 1; i < snapshots.length; i++) { 
      const snapshot = snapshots[i]; 
      const prevSnapshot = snapshots[i - 1]; 
 
      // 检查是否发生阶段转变 
      const phaseChanged = snapshot.phase !== currentPhase; 
 
      // 检查当前章节是否足够长 
      const chapterDuration = (snapshot.timestamp.getTime() - 
        snapshots[chapterStartIndex].timestamp.getTime()) / (1000 * 60 * 60 * 24); 
      const commitCount = i - chapterStartIndex; 
 
      // 满足分割条件：阶段转变 OR (章节足够长 AND 时间足够久) 
      if (phaseChanged || (commitCount >= chapterSize && chapterDuration >= minDuration)) { 
        const chapterCommits = commits.slice(chapterStartIndex, i); 
        const chapterSnapshots = snapshots.slice(chapterStartIndex, i); 
 
        if (chapterCommits.length > 0) { 
          chapters.push(this.createChapter( 
            chapterCommits, 
            chapterSnapshots, 
            chapters.length + 1 
          )); 
        } 
 
        currentPhase = snapshot.phase; 
        chapterStartIndex = i; 
      } 
    } 
 
    // 处理最后一个章节 
    if (chapterStartIndex < snapshots.length) { 
      const chapterCommits = commits.slice(chapterStartIndex); 
      const chapterSnapshots = snapshots.slice(chapterStartIndex); 
 
      if (chapterCommits.length > 0) { 
        chapters.push(this.createChapter( 
          chapterCommits, 
          chapterSnapshots, 
          chapters.length + 1 
        )); 
      } 
    } 
 
    return chapters; 
  } 
 
  /** 
   * 创建单个章节 
   */ 
  private createChapter( 
    commits: CommitInfo[], 
    snapshots: HarmonySnapshot[], 
    chapterNumber: number 
  ): NarrativeChapter { 
    const startDate = commits[0].date; 
    const endDate = commits[commits.length - 1].date; 
    const phase = snapshots[snapshots.length - 1].phase; 
    const summary = this.generateChapterSummary(commits, snapshots); 
    const keyEvents = this.extractKeyEvents(commits); 
    const contributors = this.extractContributors(commits); 
    const harmonyCurve = this.renderHarmonyCurve(snapshots); 
 
    const phaseLabels: Record<EvolutionPhase, string> = { 
      [EvolutionPhase.STEADY]: '平稳发展', 
      [EvolutionPhase.RESTRUCTURING]: '剧烈重构', 
      [EvolutionPhase.CHAOTIC]: '混乱调整', 
      [EvolutionPhase.STAGNANT]: '沉寂停滞', 
      [EvolutionPhase.HARMONIC]: '谐振状态' 
    }; 
 
    return { 
      title: `第${chapterNumber}章：${phaseLabels[phase]}`, 
      startDate, 
      endDate, 
      phase, 
      summary, 
      keyEvents, 
      contributors, 
      harmonyCurve 
    }; 
  } 
 
  /** 
   * 生成章节摘要 
   */ 
  private generateChapterSummary( 
    commits: CommitInfo[], 
    snapshots: HarmonySnapshot[] 
  ): string { 
    const totalInsertions = commits.reduce((sum, c) => sum + c.insertions, 0); 
    const totalDeletions = commits.reduce((sum, c) => sum + c.deletions, 0); 
    const totalFilesChanged = commits.reduce((sum, c) => sum + c.filesChanged, 0); 
    const avgH = snapshots.reduce((sum, s) => sum + s.H, 0) / snapshots.length; 
    const phase = snapshots[snapshots.length - 1].phase; 
 
    const summaryParts: string[] = []; 
 
    switch (phase) { 
      case EvolutionPhase.STEADY: 
        summaryParts.push('项目进入平稳发展期。'); 
        summaryParts.push(`期间完成了 ${commits.length} 次提交，`); 
        summaryParts.push(`涉及 ${totalFilesChanged} 个文件的修改，`); 
        summaryParts.push(`新增 ${totalInsertions} 行代码，删除 ${totalDeletions} 行代码。`); 
        summaryParts.push(`和谐度保持在 ${Math.round(avgH * 100)}%，代码质量稳定。`); 
        break; 
 
      case EvolutionPhase.RESTRUCTURING: 
        summaryParts.push('项目迎来剧烈重构期。'); 
        summaryParts.push(`在 ${commits.length} 次提交中，`); 
        summaryParts.push(`进行了大规模代码调整，`); 
        summaryParts.push(`新增 ${totalInsertions} 行，删除 ${totalDeletions} 行。`); 
        summaryParts.push('这是架构升级的关键时期。'); 
        break; 
 
      case EvolutionPhase.CHAOTIC: 
        summaryParts.push('项目进入混乱调整期。'); 
        summaryParts.push(`期间有 ${commits.length} 次提交，`); 
        summaryParts.push('频繁的修复和调整表明存在较多问题需要解决。'); 
        summaryParts.push(`当前和谐度为 ${Math.round(avgH * 100)}%，建议关注代码质量。`); 
        break; 
 
      case EvolutionPhase.STAGNANT: 
        summaryParts.push('项目进入沉寂停滞期。'); 
        summaryParts.push(`期间仅有 ${commits.length} 次提交，`); 
        summaryParts.push('活跃度较低，可能处于维护或等待状态。'); 
        break; 
 
      case EvolutionPhase.HARMONIC: 
        summaryParts.push('项目进入理想的谐振状态！'); 
        summaryParts.push(`在 ${commits.length} 次提交中，`); 
        summaryParts.push(`新增 ${totalInsertions} 行代码，删除 ${totalDeletions} 行，`); 
        summaryParts.push(`和谐度达到 ${Math.round(avgH * 100)}%，发展健康高效。`); 
        break; 
    } 
 
    return summaryParts.join(''); 
  } 
 
  /** 
   * 提取关键事件 
   */ 
  private extractKeyEvents(commits: CommitInfo[]): string[] { 
    // 按修改量排序，取前5个最重要的commit 
    const importantCommits = [...commits] 
      .sort((a, b) => { 
        const scoreA = a.insertions + a.deletions; 
        const scoreB = b.insertions + b.deletions; 
        return scoreB - scoreA; 
      }) 
      .slice(0, 5); 
 
    return importantCommits.map(commit => { 
      const hash = commit.shortHash || commit.hash.slice(0, 7); 
      return `${hash}: ${commit.message}`; 
    }); 
  } 
 
  /** 
   * 提取章节贡献者 
   */ 
  private extractContributors(commits: CommitInfo[]): string[] { 
    const authors = new Set(commits.map(c => c.author)); 
    return Array.from(authors).sort(); 
  } 
 
  /** 
   * 提取所有贡献者 
   */ 
  private extractAllContributors(commits: CommitInfo[]): string[] { 
    return this.extractContributors(commits); 
  } 
 
  /** 
   * 渲染和谐度曲线（ASCII艺术） 
   */ 
  private renderHarmonyCurve(snapshots: HarmonySnapshot[]): string { 
    if (snapshots.length === 0) { 
      return ''; 
    } 
 
    const maxWidth = 40; 
    const maxHeight = 8; 
    const chars = '█▉▊▋▌▍▎▏ '; 
 
    const HValues = snapshots.map(s => s.H); 
    const minH = Math.min(...HValues); 
    const maxH = Math.max(...HValues); 
    const rangeH = maxH - minH || 1; 
 
    const normalizedValues = HValues.map(h => (h - minH) / rangeH); 
 
    // 创建字符矩阵 
    const lines: string[] = []; 
    for (let row = 0; row < maxHeight; row++) { 
      let line = ''; 
      for (let col = 0; col < maxWidth; col++) { 
        const valueIndex = Math.floor((col / maxWidth) * normalizedValues.length); 
        const value = normalizedValues[valueIndex]; 
        const charIndex = Math.floor(value * (chars.length - 1)); 
        line += chars[charIndex]; 
      } 
      lines.push(line); 
    } 
 
    return lines.join('\n'); 
  } 
 
  /** 
   * 计算整体和谐度 
   */ 
  private computeOverallHarmony(snapshots: HarmonySnapshot[]): number { 
    if (snapshots.length === 0) { 
      return 0; 
    } 
 
    // 使用加权平均，最近的快照权重更高 
    let totalWeight = 0; 
    let weightedSum = 0; 
 
    for (let i = 0; i < snapshots.length; i++) { 
      const weight = i + 1; // 线性递增权重 
      weightedSum += snapshots[i].H * weight; 
      totalWeight += weight; 
    } 
 
    return weightedSum / totalWeight; 
  } 
 
  /** 
   * 生成演化故事 
   */ 
  private generateEvolutionStory(chapters: NarrativeChapter[], overallHarmony: number): string { 
    if (chapters.length === 0) { 
      return '这个项目的故事还未开始书写。'; 
    } 
 
    const storyParts: string[] = []; 
 
    // 开头 
    const phaseDistribution = this.countPhaseDistribution(chapters); 
    storyParts.push(`这个项目共有 ${chapters.length} 个演化阶段，`); 
    storyParts.push(`其中平稳发展期 ${phaseDistribution[EvolutionPhase.STEADY]} 个，`); 
    storyParts.push(`剧烈重构期 ${phaseDistribution[EvolutionPhase.RESTRUCTURING]} 个，`); 
    storyParts.push(`混乱调整期 ${phaseDistribution[EvolutionPhase.CHAOTIC]} 个，`); 
    storyParts.push(`沉寂停滞期 ${phaseDistribution[EvolutionPhase.STAGNANT]} 个，`); 
    storyParts.push(`谐振状态 ${phaseDistribution[EvolutionPhase.HARMONIC]} 个。\n`); 
 
    // 整体评价 
    if (overallHarmony >= 0.8) { 
      storyParts.push('项目整体处于理想的谐振状态，发展健康高效。'); 
      storyParts.push('代码质量优秀，团队协作顺畅。'); 
    } else if (overallHarmony >= 0.6) { 
      storyParts.push('项目整体和谐度良好，处于平稳发展阶段。'); 
      storyParts.push('建议继续保持当前的开发节奏。'); 
    } else if (overallHarmony >= 0.4) { 
      storyParts.push('项目整体和谐度一般，存在一些需要关注的问题。'); 
      storyParts.push('建议分析高对抗性阶段，找出问题根源。'); 
    } else { 
      storyParts.push('项目整体和谐度较低，需要重点关注。'); 
      storyParts.push('建议进行代码审查和架构优化。'); 
    } 
 
    return storyParts.join(''); 
  } 
 
  /** 
   * 统计各阶段分布 
   */ 
  private countPhaseDistribution(chapters: NarrativeChapter[]): Record<EvolutionPhase, number> { 
    const counts: Record<EvolutionPhase, number> = { 
      [EvolutionPhase.STEADY]: 0, 
      [EvolutionPhase.RESTRUCTURING]: 0, 
      [EvolutionPhase.CHAOTIC]: 0, 
      [EvolutionPhase.STAGNANT]: 0, 
      [EvolutionPhase.HARMONIC]: 0 
    }; 
 
    chapters.forEach(chapter => { 
      counts[chapter.phase]++; 
    }); 
 
    return counts;
  }
}
