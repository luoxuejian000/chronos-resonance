/** 
 * GitNarrative 全局配置 
 * 
 * 所有权重值均为"协商起点"，可通过配置文件覆盖 
 * 这体现了谐振调谐论中"价值抉择透明化"的原则 
 */ 
 
export const CONFIG = { 
  /** 和谐度权重系数 */ 
  weights: { 
    /** λᵤ 统一性权重：修改聚焦度和消息一致性的重要程度 */ 
    consistency: 0.4, 
    /** λᴅ 发展性权重：新功能和代码增长的重要程度 */ 
    development: 0.3, 
    /** λₐ 对抗性权重：修复和冲突对和谐度的惩罚强度 */ 
    antagonism: 0.3 
  }, 
 
  /** 演化阶段判定阈值 */ 
  thresholds: { 
    /** H >= 0.8: 谐振态 */ 
    harmonic: 0.8, 
    /** H >= 0.6: 平稳态 */ 
    steady: 0.6, 
    /** H >= 0.4: 审慎态 */ 
    warning: 0.4, 
    /** H < 0.2: 失谐态 */ 
    critical: 0.2 
  }, 
 
  /** Commit 关系分析参数 */ 
  coupling: { 
    /** 时间窗口（天）：在此窗口内的commit被视为可能相关 */ 
    timeWindowDays: 7, 
    /** 最小共享文件数：两个commit共享此数量的文件时被认为耦合 */ 
    minSharedFiles: 2, 
    /** 高插入量阈值：超过此行数的insertion被视为"大规模新增" */ 
    highInsertionThreshold: 200, 
    /** 高删除量阈值：超过此行数的deletion被视为"大规模删除" */ 
    highDeletionThreshold: 150 
  }, 
 
  /** 叙事生成参数 */ 
  narrative: { 
    /** 每章包含的commit数 */ 
    chapterSize: 20, 
    /** 每章最小持续时间（天） */ 
    minChapterDuration: 3, 
    /** H(t) 平滑窗口大小 */ 
    smoothingWindow: 5 
  } 
}; 
