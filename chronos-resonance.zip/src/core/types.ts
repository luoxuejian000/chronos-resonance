/** 
 * GitNarrative 核心类型定义 
 * 
 * 理论根基：晶脉哲学四重公理 
 * - 关系本体论：Commit 不是孤立事件，而是关系网络中的节点 
 * - 矛盾动力论：修复与回滚不是故障，而是项目演化的能量源 
 * - 谐振调谐论：通过和谐度 H(t) 追踪项目的自组织演化轨迹 
 */ 
 
/** 一次 Git 提交的结构化信息 */ 
export interface CommitInfo { 
  hash: string; 
  shortHash: string; 
  author: string; 
  email: string; 
  date: Date; 
  message: string; 
  filesChanged: number; 
  insertions: number; 
  deletions: number; 
  isMerge: boolean; 
  tags: string[]; 
} 
 
/** 
 * 项目演化阶段 
 * 基于和谐度四元组 (U, D, A, H) 的分类 
 */ 
export enum EvolutionPhase { 
  /** 平稳发展期：高U 低A —— 修改聚焦，结构稳定 */ 
  STEADY = 'steady', 
  /** 剧烈重构期：高D 高A —— 大规模代码替换 */ 
  RESTRUCTURING = 'restructuring', 
  /** 混乱调整期：低U 高A —— 大量修复和回滚 */ 
  CHAOTIC = 'chaotic', 
  /** 沉寂停滞期：低D 低A —— 变更量极低 */ 
  STAGNANT = 'stagnant', 
  /** 谐振态：高U 高D 低A —— 增长健康，协作高效 */ 
  HARMONIC = 'harmonic' 
} 
 
/** 和谐度四元组快照 */ 
export interface HarmonySnapshot { 
  timestamp: Date; 
  /** 统一性 Unity: 修改聚焦度、文件耦合紧密程度 */ 
  U: number; 
  /** 发展性 Development: 新功能引入频率、代码增长速率 */ 
  D: number; 
  /** 对抗性 Antagonism: 修复频率、回滚频率、冲突频率 */ 
  A: number; 
  /** 和谐度 Harmony: H = λᵤ·U - λᴅ·D - λₐ·A */ 
  H: number; 
  commitCount: number; 
  phase: EvolutionPhase; 
} 
 
/** 叙事章节 */ 
export interface NarrativeChapter { 
  title: string; 
  startDate: Date; 
  endDate: Date; 
  phase: EvolutionPhase; 
  summary: string; 
  keyEvents: string[]; 
  contributors: string[]; 
  harmonyCurve: string; 
} 
 
/** 项目演化自传 */ 
export interface ProjectAutobiography { 
  projectName: string; 
  totalCommits: number; 
  totalContributors: number; 
  timespan: { start: Date; end: Date }; 
  chapters: NarrativeChapter[]; 
  overallHarmony: number; 
  evolutionStory: string; 
} 
 
/** Git 解析选项 */ 
export interface ParseOptions { 
  repoPath: string; 
  maxCommits?: number; 
  since?: string; 
  until?: string; 
  branch?: string; 
} 
